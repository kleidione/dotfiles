#
# ~/.bashrc
#

# If not running interactively, don't do anything
[[ $- != *i* ]] && return

alias ls='ls --color=auto'
PS1="\u@\h\n>\[$(tput sgr0)\]"
(cat ~/.cache/wal/sequences &)
