#!/bin/bash

cp -R {.config,.local,.bin,.themes,.bashrc,.xinitrc,Wallpapers,Screenshots,popy} /home/$USER
chmod +x ~/.bin/openbox-logout ; sh ~/.config/polybar/launch.sh; openbox --reconfigure
cd ~/popy && ./popy.in --pywal
exit
